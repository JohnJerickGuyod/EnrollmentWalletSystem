/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package enrollmentwallet;

/**
 *
 * @author ADMIN
 */
public class Course {
    String courseCode;
    String courseTitle;
    int units;
    
    public Course(String courseCode, String courseTitle, int units){
        this.courseCode = courseCode;
        this.courseTitle = courseTitle;
        this.units = units;
    }
    
    public String getCourseCode(){
    return courseCode;
    }
    
    public int getUnits(){
    return units;
    }
    
    public void updateUnits(int newUnits){
    units = newUnits;
    }
    
    public void displayCourse(){
    System.out.println("Course Code " + courseCode);
    System.out.println("Course Title " + courseTitle);
    System.out.println("Units " + units);
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package enrollmentwallet;

/**
 *
 * @author ADMIN
 */
public class DigitalWallet {
    String walletId;
    String ownerName;
    double balance;
    
    public DigitalWallet(){
        this.walletId = "UNKNOWN";
        this.ownerName = "UNKNOWN";
        this.balance = 0.00;
    }
    
    public DigitalWallet(String walletId, String ownerName){
        this.walletId = walletId;
        this.ownerName = ownerName;
        this.balance = 0.00;
    }
    
    public DigitalWallet(String walletId, String ownerName, double balance){
        this.walletId = walletId;
        this.ownerName = ownerName;
        this.balance = balance;
    }
    
    public void deposit(double amount){
        balance+=amount;
    }
    
    public boolean withdraw(double amount){
        if(balance > amount){
            balance-=amount;
            return true;
        }if(balance < 0){
            balance = 0;
        }
        return false;
        
    }
     
    public void displayWallet(){
        System.out.println("Wllet ID " + walletId);
        System.out.println("Owner Name " + ownerName);
        System.out.println("Balance " + balance);
    };

}

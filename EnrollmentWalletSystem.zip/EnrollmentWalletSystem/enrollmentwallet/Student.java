/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package enrollmentwallet;

/**
 *
 * @author ADMIN
 */
public class Student {
    String studentId;
    String name;
    String program;
    DigitalWallet wallet;
    
    public Student(String studentId, String name, String program, DigitalWallet wallet){
        this.studentId = studentId;
        this.name = name;
        this.program = program;
        this.wallet = wallet;
    }
    
    public String getStudentId(){
    return studentId;
    }
    
    public String getProgram(){
    return program;
    }
    
    public void changeProgram(String newProgram){
    program = newProgram;  
    }
    
    public void displayStudent(){
    System.out.println("Student ID " + studentId);
    System.out.println("Name " + name);
    System.out.println("Porgram " + program);
    System.out.println("Wallet " + wallet);
    }
}


package enrollmentwalletsystem;

public class EnrollmentWalletSystem {

    public static void main(String[] args) {
        labchecker.GradeEngine.runTests();
    }

}
